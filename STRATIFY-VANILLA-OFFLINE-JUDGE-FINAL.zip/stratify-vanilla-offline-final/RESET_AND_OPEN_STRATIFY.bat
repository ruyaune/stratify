@echo off
cd /d "%~dp0"
start "" "%~dp0index.html?reset=1"
exit /b 0
