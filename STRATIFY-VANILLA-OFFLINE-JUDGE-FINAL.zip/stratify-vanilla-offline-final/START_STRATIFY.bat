@echo off
cd /d "%~dp0"
start "" "%~dp0index.html"
exit /b 0
